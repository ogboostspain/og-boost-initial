package es.ogboost.banktech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BanktechApplication {

	public static void main(String[] args) {
		SpringApplication.run(BanktechApplication.class, args);
	}

}
